/**
 * Map Section and Achievement Section JavaScript
 * Creates interactive map and achievement section with scroll effects
 */

// Initialize Map Section
function initializeMapSection() {
    // Check if map section already exists
    if (document.querySelector('.map-section')) return;
    
    // Create map section before the contact section
    const contactSection = document.getElementById('contact');
    if (!contactSection) return;
    
    const mapSection = document.createElement('section');
    mapSection.id = 'map';
    mapSection.className = 'section map-section';
    mapSection.setAttribute('data-section', 'map');
    
    mapSection.innerHTML = `
        <div class="content-container">
            <h2 class="section-title">Global Presence</h2>
            <p class="section-subtitle">Transforming hospitality across continents.</p>
            
            <div class="map-container">
                <div class="map-overlay"></div>
                <div class="map-content">
                    <h3 class="map-title">Strategic Partnerships</h3>
                    <p class="map-description">Our network spans major cultural centers and innovation hubs, creating a global ecosystem of transformative hospitality infrastructure.</p>
                </div>
                <div class="map-points">
                    <!-- Map points will be added dynamically -->
                </div>
                <div class="map-background">
                    <div class="map-grid"></div>
                    <div class="map-lines"></div>
                </div>
            </div>
        </div>
        
        <!-- Section Arc -->
        <svg class="section-arc bottom" viewBox="0 0 200 100" preserveAspectRatio="none">
            <path d="M 0,0 Q 100,100 200,0" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1"/>
        </svg>
    `;
    
    // Insert before contact section
    contactSection.parentNode.insertBefore(mapSection, contactSection);
    
    // Add map points
    const mapPoints = [
        { x: 20, y: 30, label: 'New York' },
        { x: 15, y: 40, label: 'Miami' },
        { x: 10, y: 35, label: 'Mexico City' },
        { x: 45, y: 25, label: 'London' },
        { x: 48, y: 30, label: 'Paris' },
        { x: 52, y: 28, label: 'Berlin' },
        { x: 60, y: 35, label: 'Dubai' },
        { x: 75, y: 30, label: 'Singapore' },
        { x: 80, y: 45, label: 'Sydney' },
        { x: 85, y: 25, label: 'Tokyo' }
    ];
    
    const mapPointsContainer = document.querySelector('.map-points');
    if (mapPointsContainer) {
        mapPoints.forEach(point => {
            const mapPoint = document.createElement('div');
            mapPoint.className = 'map-point';
            mapPoint.style.left = `${point.x}%`;
            mapPoint.style.top = `${point.y}%`;
            
            const label = document.createElement('div');
            label.className = 'map-point-label';
            label.textContent = point.label;
            
            mapPoint.appendChild(label);
            mapPointsContainer.appendChild(mapPoint);
        });
    }
    
    // Add map lines
    const mapLinesContainer = document.querySelector('.map-lines');
    if (mapLinesContainer) {
        // Connect some points with lines
        const connections = [
            [0, 1], [0, 3], [3, 4], [3, 5], [5, 6], [6, 7], [7, 8], [7, 9]
        ];
        
        connections.forEach(connection => {
            const point1 = mapPoints[connection[0]];
            const point2 = mapPoints[connection[1]];
            
            const dx = point2.x - point1.x;
            const dy = point2.y - point1.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const angle = Math.atan2(dy, dx) * 180 / Math.PI;
            
            const line = document.createElement('div');
            line.className = 'map-line';
            line.style.width = `${distance}%`;
            line.style.height = '1px';
            line.style.left = `${point1.x}%`;
            line.style.top = `${point1.y}%`;
            line.style.transform = `rotate(${angle}deg)`;
            
            mapLinesContainer.appendChild(line);
        });
    }
    
    // Add to navigation dots
    const navDots = document.querySelector('.nav-dots');
    if (navDots) {
        const mapDot = document.createElement('button');
        mapDot.className = 'nav-dot';
        mapDot.setAttribute('data-section', 'map');
        mapDot.setAttribute('aria-label', 'Navigate to Map section');
        
        const dotInner = document.createElement('span');
        dotInner.className = 'dot-inner';
        
        mapDot.appendChild(dotInner);
        
        // Insert before contact dot
        const contactDot = document.querySelector('.nav-dot[data-section="contact"]');
        if (contactDot) {
            navDots.insertBefore(mapDot, contactDot);
        } else {
            navDots.appendChild(mapDot);
        }
        
        // Add click event
        mapDot.addEventListener('click', () => {
            const section = document.querySelector('[data-section="map"]');
            if (section) {
                section.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }
}

// Initialize Achievement Section
function initializeAchievementSection() {
    // Check if achievement section already exists
    if (document.querySelector('.achievement-section')) return;
    
    // Create achievement section before the map section
    const mapSection = document.getElementById('map');
    if (!mapSection) return;
    
    const achievementSection = document.createElement('section');
    achievementSection.id = 'achievements';
    achievementSection.className = 'section achievement-section';
    achievementSection.setAttribute('data-section', 'achievements');
    
    achievementSection.innerHTML = `
        <div class="content-container">
            <h2 class="section-title">Transformative Impact</h2>
            <p class="section-subtitle">Measurable results across our partnerships.</p>
            
            <div class="achievement-grid">
                <div class="achievement-item" data-index="1">
                    <div class="achievement-number">87%</div>
                    <h3 class="achievement-title">Engagement Increase</h3>
                    <p class="achievement-description">Average increase in community engagement metrics across cultural institution partnerships.</p>
                </div>
                
                <div class="achievement-item" data-index="2">
                    <div class="achievement-number">3.2x</div>
                    <h3 class="achievement-title">Loyalty Growth</h3>
                    <p class="achievement-description">Average growth in loyalty program participation after infrastructure redesign.</p>
                </div>
                
                <div class="achievement-item" data-index="3">
                    <div class="achievement-number">42%</div>
                    <h3 class="achievement-title">Revenue Impact</h3>
                    <p class="achievement-description">Average increase in ancillary revenue streams through enhanced hospitality touchpoints.</p>
                </div>
            </div>
        </div>
        
        <!-- Section Arc -->
        <svg class="section-arc bottom" viewBox="0 0 200 100" preserveAspectRatio="none">
            <path d="M 0,0 Q 100,100 200,0" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1"/>
        </svg>
    `;
    
    // Insert before map section
    mapSection.parentNode.insertBefore(achievementSection, mapSection);
    
    // Add to navigation dots
    const navDots = document.querySelector('.nav-dots');
    if (navDots) {
        const achievementDot = document.createElement('button');
        achievementDot.className = 'nav-dot';
        achievementDot.setAttribute('data-section', 'achievements');
        achievementDot.setAttribute('aria-label', 'Navigate to Achievements section');
        
        const dotInner = document.createElement('span');
        dotInner.className = 'dot-inner';
        
        achievementDot.appendChild(dotInner);
        
        // Insert before map dot
        const mapDot = document.querySelector('.nav-dot[data-section="map"]');
        if (mapDot) {
            navDots.insertBefore(achievementDot, mapDot);
        } else {
            navDots.appendChild(achievementDot);
        }
        
        // Add click event
        achievementDot.addEventListener('click', () => {
            const section = document.querySelector('[data-section="achievements"]');
            if (section) {
                section.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }
    
    // Initialize scroll animation for achievement items
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.2
    };
    
    const achievementObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                // Add staggered animation delay
                const index = entry.target.getAttribute('data-index');
                entry.target.style.transitionDelay = `${(index - 1) * 0.2}s`;
            }
        });
    }, observerOptions);
    
    const achievementItems = document.querySelectorAll('.achievement-item');
    achievementItems.forEach(item => {
        achievementObserver.observe(item);
    });
}

// Call these functions from the main initialization
document.addEventListener('DOMContentLoaded', () => {
    // Add to existing initialization
    setTimeout(() => {
        initializeMapSection();
        initializeAchievementSection();
    }, 2000);
});
