/**
 * Sound Visualization and Audio Handling
 * Creates a visual representation of audio frequencies
 */

function initializeSoundVisualization() {
    const audioToggle = document.querySelector('.audio-toggle');
    const audioElement = document.getElementById('ambient-audio');
    
    // Create visualization container if it doesn't exist
    if (!document.querySelector('.sound-visualization')) {
        const visualizationContainer = document.createElement('div');
        visualizationContainer.classList.add('sound-visualization');
        
        // Create sound bars
        const soundBars = document.createElement('div');
        soundBars.classList.add('sound-bars');
        
        for (let i = 0; i < 5; i++) {
            const bar = document.createElement('div');
            bar.classList.add('sound-bar');
            soundBars.appendChild(bar);
        }
        
        visualizationContainer.appendChild(soundBars);
        document.body.appendChild(visualizationContainer);
    }
    
    const visualization = document.querySelector('.sound-visualization');
    
    // Update visualization when audio plays
    if (audioElement) {
        // Set up audio context and analyzer
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        const audioContext = new AudioContext();
        const analyser = audioContext.createAnalyser();
        const source = audioContext.createMediaElementSource(audioElement);
        
        source.connect(analyser);
        analyser.connect(audioContext.destination);
        
        analyser.fftSize = 32;
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        
        // Update visualization based on frequency data
        function updateVisualization() {
            if (audioElement.paused) {
                visualization.classList.remove('active');
                return;
            }
            
            visualization.classList.add('active');
            analyser.getByteFrequencyData(dataArray);
            
            const bars = document.querySelectorAll('.sound-bar');
            for (let i = 0; i < bars.length; i++) {
                const index = Math.floor(i * (bufferLength / bars.length));
                const value = dataArray[index];
                const height = value / 255 * 20 + 5; // Scale to reasonable height
                bars[i].style.height = `${height}px`;
            }
            
            requestAnimationFrame(updateVisualization);
        }
        
        // Toggle audio and visualization
        if (audioToggle) {
            audioToggle.addEventListener('click', () => {
                if (audioContext.state === 'suspended') {
                    audioContext.resume();
                }
                
                if (audioElement.paused) {
                    audioElement.play();
                    audioToggle.setAttribute('data-state', 'active');
                    updateVisualization();
                } else {
                    audioElement.pause();
                    audioToggle.setAttribute('data-state', 'inactive');
                    visualization.classList.remove('active');
                }
            });
        }
    }
}

// Add keyword nebula to star constellations
function addKeywordNebulas() {
    const container = document.querySelector('.app-container');
    if (!container) return;
    
    const keywords = [
        { text: 'hospitality sentiment', x: 25, y: 30 },
        { text: 'touchpoint', x: 70, y: 40 },
        { text: 'experiences', x: 40, y: 70 }
    ];
    
    keywords.forEach(keyword => {
        const nebula = document.createElement('div');
        nebula.classList.add('keyword-nebula');
        nebula.textContent = keyword.text;
        
        // Position relative to viewport size
        const xPos = window.innerWidth * (keyword.x / 100);
        const yPos = window.innerHeight * (keyword.y / 100);
        
        nebula.style.left = `${xPos}px`;
        nebula.style.top = `${yPos}px`;
        
        container.appendChild(nebula);
    });
}

// Enhance scroll-triggered text highlighting
function enhanceScrollHighlighting() {
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    // Create observer for text elements
    const textObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('highlight-text');
                
                // Add staggered animation for child elements
                const children = entry.target.querySelectorAll('p, li, h3');
                children.forEach((child, index) => {
                    child.style.transitionDelay = `${index * 0.15}s`;
                    child.classList.add('highlight-text');
                });
            }
        });
    }, observerOptions);
    
    // Observe text containers
    const textContainers = document.querySelectorAll('.prose, .capability-block, .partnership-category');
    textContainers.forEach(container => {
        textObserver.observe(container);
    });
}

// Initialize brand logo section
function initializeLogoSection() {
    // Check if testimonial section exists
    const testimonial = document.querySelector('.testimonial');
    if (!testimonial) return;
    
    // Create logo section if it doesn't exist
    if (!document.querySelector('.logo-section')) {
        const logoSection = document.createElement('div');
        logoSection.classList.add('logo-section');
        
        // Add title
        const title = document.createElement('h3');
        title.classList.add('logo-section-title');
        title.textContent = 'Trusted By';
        logoSection.appendChild(title);
        
        // Create logo container
        const logoContainer = document.createElement('div');
        logoContainer.classList.add('logo-container');
        
        // Add placeholder logos
        for (let i = 0; i < 5; i++) {
            const logo = document.createElement('div');
            logo.classList.add('partner-logo');
            
            // Create SVG placeholder
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('viewBox', '0 0 100 40');
            svg.setAttribute('fill', 'none');
            
            // Add simple shape as placeholder
            const shape = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            
            // Different shape for each logo
            if (i === 0) {
                shape.setAttribute('d', 'M20,10 h60 v20 h-60 z');
            } else if (i === 1) {
                shape.setAttribute('d', 'M30,10 a20,20 0 1,0 40,0 a20,20 0 1,0 -40,0');
            } else if (i === 2) {
                shape.setAttribute('d', 'M20,20 L50,10 L80,20 L50,30 z');
            } else if (i === 3) {
                shape.setAttribute('d', 'M30,10 L70,10 L80,20 L70,30 L30,30 L20,20 z');
            } else {
                shape.setAttribute('d', 'M20,10 Q50,30 80,10 Q50,-10 20,10');
            }
            
            shape.setAttribute('stroke', 'currentColor');
            shape.setAttribute('stroke-width', '1');
            shape.setAttribute('fill', 'none');
            
            svg.appendChild(shape);
            logo.appendChild(svg);
            logoContainer.appendChild(logo);
        }
        
        logoSection.appendChild(logoContainer);
        
        // Insert after testimonial
        testimonial.parentNode.insertBefore(logoSection, testimonial.nextSibling);
    }
}

// Call these new functions from the main initialization
document.addEventListener('DOMContentLoaded', () => {
    // Add to existing initialization
    setTimeout(() => {
        initializeSoundVisualization();
        addKeywordNebulas();
        enhanceScrollHighlighting();
        initializeLogoSection();
    }, 2000);
});
